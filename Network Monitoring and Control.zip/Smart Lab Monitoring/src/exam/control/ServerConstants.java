/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam.control;


public class ServerConstants {
    
    public static boolean ucbrowser = false;
    public static boolean internetexp = false;
    public static boolean chrome = false;
    public static boolean mozilla = false;
    
   
    public static boolean pendrivedetect = false;
    
    public static boolean appdetect1 = false;
    public static boolean appdetect2 = false;
    public static boolean appdetect3 = false;
    public static boolean appdetect4 = false;
    public static boolean appdetect5 = false;
    
    public static boolean flagsall = true;
    
    
    public static String startallbrowser = "STARTALLBROWSER";
    public static String startpendrive = "STARTPENDRIVE";
    
    public static String startapp1;
    public static String startapp2;
    public static String startapp3;
    public static String startapp4;
    public static String startapp5;
}
